devsummit2013-flex-samples
==========================

Some Flex API samples created for the 2013 Developer Summit in Palm Springs

###[AttributeTable_Basic](http://bsvensson.github.com/devsummit2013-flex-samples/AttributeTable_Basic.html)###
* Minimum code for using the AttributeTable component: FeatureLayer and AttributeTable.

###[AttributeTable_Editing](http://bsvensson.github.com/devsummit2013-flex-samples/AttributeTable_Editing.html)####
* Editing attributes with AttributeTable component.
* Requires an editable feature layer.
* API component throws update and delete events.

###[AttributeTable_Map](http://bsvensson.github.com/devsummit2013-flex-samples/AttributeTable_Map.html)###
* Using Map and AttributeTable together - just add the Map :)

###[WebTiledLayer_Basic](http://bsvensson.github.com/devsummit2013-flex-samples/WebTiledLayer_Basic.html)###
* Minimum code for using the WebTiledLayer class: specifying WebTiledLayer.urlTemplate property.

